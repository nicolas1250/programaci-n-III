export class Tarea {
    nombre: string;
    jugadoresPorEquipo:number;
    duracionPartido:number;
    popularidadGlobal:string;
    origen:string;
}
