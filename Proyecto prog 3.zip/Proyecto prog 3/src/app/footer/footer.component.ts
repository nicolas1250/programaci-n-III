import { Component } from '@angular/core';

@Component({
  selector: 'app-footer',
  standalone: true,
  imports: [],
  templateUrl: './footer.component.html',
  styleUrl: './footer.component.css'
})
export class FooterComponent {
  autor:any = {nombres:'Karen Johana', apellidos:'Caicedo Arias'}
  autor2:any = {nombres:'Nicolas', apellidos:'Obregon Rojas'}
  autor3:any = {nombres:'Programación 3', apellidos:'Grupo 2 - Corhuila'}
}
